import { api, auth, login, userAvatarUrl } from "./api.js";
import { esc, toast, errText } from "./ui.js";
import { mountDataExchange } from "./data_exchange.js";

const root = document.getElementById("app");
// سجل الشاشات: route → وحدة الواجهة. أي شاشة جديدة تتضاف هنا.
const L = f => () => import(f);
const SCREENS = {
  "/checks/register": L("./pages/financial_checks.js?v=20261104-check-project-link-1"),
  "/financial-checks": L("./pages/financial_checks.js?v=20261104-check-project-link-1"),
  "/checks-register": L("./pages/financial_checks.js?v=20261104-check-project-link-1"),
  "/admin/users": L("./pages/admin.js?v=20261019-user-avatar-1"),
  "/admin/backup": L("./pages/backup.js"),
  "/admin/company": L("./pages/company.js?v=20261104-company-profile-1"),
  "/accounts": L("./pages/accounts.js"),
  "/projects": L("./pages/projects.js"),
  "/journal": L("./pages/journal.js?v=20261105-journal-description-separators-1"),
  "/trial-balance": L("./pages/trial_balance.js"),
  "/reports/balance-sheet": L("./pages/reports.js"),
  "/reports/income-statement": L("./pages/reports.js"),
  "/reports": L("./pages/reports_analytics.js?v=20261104-searchable-account-1"),
  "/contracts": L("./pages/contracts.js?v=20261104-company-print-1"),
  "/contract-requests": L("./pages/contract_requests.js?v=20261018-contract-auto-number-1"),
  "/settlements": L("./pages/settlements.js?v=20261104-company-print-1"),
  "/inventory": L("./pages/inventory.js?v=20261023-stock-card-1"),
  "/purchases": L("./pages/purchases.js?v=20261018-purchase-warehouse-flow-2"),
  "/counterparties": L("./pages/counterparties.js?v=20261104-customer-close-1"),
  // Preserve the older type-specific links while using the unified party registry.
  "/customers": L("./pages/counterparties.js?v=20261104-customer-close-1"),
  "/contractors": L("./pages/counterparties.js?v=20261104-customer-close-1"),
  "/suppliers": L("./pages/counterparties.js?v=20261104-customer-close-1"),
  "/audit-logs": L("./pages/audit_logs.js"),
  "/treasury/analysis": L("./pages/cash_analysis.js"),
  "/treasury/reconciliation": L("./pages/reconciliation.js"),
  ...Object.fromEntries(["cib-egp", "cash-usd", "cash-egp", "cairo-egp", "hdb-usd", "hdb-egp", "cib-usd"].map(k => ["/treasury/" + k, L("./pages/treasury.js?v=20261104-cash-egp-1")])),
  ...Object.fromEntries(["cib", "cairo-egp", "cairo-usd"].map(k => ["/checks/" + k, L("./pages/checks.js")])),
};

// ---------------------------------------------------------------- أيقونات (SVG خطي بسيط)
const ICON = {
  home: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v10h13V10"/><path d="M10 20v-5h4v5"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/>',
  book: '<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z"/><path d="M5 17a3 3 0 0 1 3-3h11"/>',
  scale: '<path d="M12 4v16M6 20h12M5 8h14"/><path d="M5 8l-3 6a3 3 0 0 0 6 0zM19 8l-3 6a3 3 0 0 0 6 0z"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
  bank: '<path d="M3 10 12 4l9 6M5 10v8M9.5 10v8M14.5 10v8M19 10v8M3 20h18"/>',
  card: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h4"/>',
  users: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><path d="M16 5.2a3 3 0 0 1 0 5.6M17.5 14.3c2.2.6 3.5 2.6 3.5 5.7"/>',
  cloud: '<path d="M7 18a4.5 4.5 0 0 1-.5-9A6 6 0 0 1 18 9.5 4 4 0 0 1 17.5 18"/><path d="M12 11v8M9 14l3-3 3 3"/>',
  bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
  logout: '<path d="M10 4H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h5"/><path d="M15 8l4 4-4 4M19 12H9"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5 19 19M5 19l1.5-1.5M17.5 6.5 19 5"/>',
  moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
  dollar: '<circle cx="12" cy="12" r="9"/><path d="M14.5 9.2c-.4-1-1.4-1.6-2.6-1.6-1.5 0-2.6.8-2.6 2s1 1.7 2.7 2.1c1.7.4 2.7 1 2.7 2.2s-1.1 2-2.7 2c-1.3 0-2.3-.6-2.7-1.6M12 6v1.6M12 16.4V18"/>',
  swap: '<path d="M4 8h14l-3-3M20 16H6l3 3"/>',
  receipt: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
  target: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r=".6"/>',
  pie: '<path d="M12 3v9h9"/><path d="M20.5 15A9 9 0 1 1 9 3.5"/>',
  check: '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l3 3 5-6"/>',
  chevron: '<path d="M6 9l6 6 6-6"/>',
  file: '<path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>',
  printer: '<path d="M7 9V4h10v5M7 17H5a1 1 0 0 1-1-1v-5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v5a1 1 0 0 1-1 1h-2"/><path d="M7 14h10v6H7z"/>',
  dot: '<circle cx="12" cy="12" r="2"/>',
};
const ico = (n, cls = "") => `<svg class="ico ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON[n] || ICON.dot}</svg>`;

// ---------------------------------------------------------------- حالة الجلسة (بتتحمّل مرة بعد الدخول)
let NAV = null, IS_ADMIN = false, SUMMARY = null;
const resetSession = () => { NAV = null; IS_ADMIN = false; SUMMARY = null; };
async function ensureNav() {
  if (NAV) return;
  NAV = await api("/dashboard");
  try { IS_ADMIN = !!(await api("/admin/status")).is_admin; } catch { IS_ADMIN = false; }
  try { SUMMARY = await api("/dashboard/summary"); } catch { SUMMARY = null; }
}

// ترتيب القائمة الجانبية: الحسابات مباشرة، والباقي مجموعات قابلة للطي
const SEC_ORDER = ["ACCOUNTING", "REPORTS", "TREASURY", "CHECKS"];
const FLAT = new Set(["ACCOUNTING"]);
const SCR_ORDER = ["ChartOfAccounts", "JournalBook", "TrialBalance", "CostCenters"];
const SEC_ICON = { REPORTS: "chart", TREASURY: "bank", CHECKS: "card" };
const SCR_ICON = { ChartOfAccounts: "list", JournalBook: "book", TrialBalance: "scale", CostCenters: "target", BalanceSheet: "file", IncomeStatement: "chart", AnalyticsReports: "chart", AuditLogs: "receipt", CashAnalysis: "pie", BankReconciliation: "check" };
const tOf = x => x.title_ar || x.title_en;
const rank = (arr, v) => { const i = arr.indexOf(v); return i < 0 ? 99 : i; };
const isHrSection = s => /^(hr|human[_ -]?resources)$/i.test(String(s.code || "").trim())
  || /موارد\s*بشرية|human\s*resources/i.test(`${s.name_ar || ""} ${s.name_en || ""}`);
const sectionsOrdered = () => (NAV?.sections || []).filter(s => !isHrSection(s)).slice().sort((a, b) => rank(SEC_ORDER, a.code) - rank(SEC_ORDER, b.code));
const screensOf = s => s.code === "ACCOUNTING" ? s.screens.slice().sort((a, b) => rank(SCR_ORDER, a.code) - rank(SCR_ORDER, b.code)) : s.screens;
const ADMIN_ITEMS = [
  { route: "/admin/company", title: "بيانات الشركة", icon: "file" },
  { route: "/admin/users", title: "المستخدمون والصلاحيات", icon: "users" },
  { route: "/admin/backup", title: "النسخ الاحتياطي", icon: "cloud" },
];

function navItems() {          // كل الوجهات (للبحث العام)
  const out = [{ route: "/", title: "الرئيسية", sub: "Home" }];
  for (const s of sectionsOrdered()) for (const x of screensOf(s)) out.push({ route: x.route, title: tOf(x), sub: x.title_en });
  if (IS_ADMIN) for (const a of ADMIN_ITEMS) out.push({ route: a.route, title: a.title, sub: "Admin" });
  return out;
}
function titleOf(path) {
  if (path === "/") return "الرئيسية";
  if (path === "/customers") return "العملاء";
  if (path === "/contractors") return "المقاولون";
  if (path === "/suppliers") return "الموردون";
  if (["/checks/register", "/financial-checks", "/checks-register"].includes(path)) return "إدارة الشيكات المالية";
  if (path === "/admin/users") return "";            // الصفحة نفسها فيها عنوانها
  if (path === "/admin/backup") return "النسخ الاحتياطي";
  if (path === "/admin/company") return "بيانات الشركة";
  if (path === "/audit-logs") return "سجل المراجعة والنشاطات";
  if (path === "/reports") return "مركز التقارير";
  if (path === "/contracts") return "العقود والمكتب الفني";
  if (path === "/contract-requests") return "طلبات التعاقد";
  if (path === "/settlements") return "مستخلصات العملاء ومقاولي الباطن";
  if (path === "/inventory") return "إدارة المخزون";
  if (path === "/purchases") return "دورة المشتريات";
  for (const s of sectionsOrdered()) for (const x of s.screens) if (x.route === path) return tOf(x);
  return "";
}

function navHtml(path) {
  const link = (it, sub) => `<a class="nav-i${it.route === path ? " on" : ""}${SCREENS[it.route] || it.route === "/" ? "" : " soon"}" href="#${esc(it.route)}">${sub ? "" : ico(it.icon)}<span>${esc(it.title)}</span></a>`;
  let h = link({ route: "/", title: "الرئيسية", icon: "home" });
  for (const s of sectionsOrdered()) {
    const scr = screensOf(s);
    if (FLAT.has(s.code)) { h += scr.map(x => link({ route: x.route, title: tOf(x), icon: SCR_ICON[x.code] || "dot" })).join(""); continue; }
    const open = scr.some(x => x.route === path);
    h += `<div class="nav-g${open ? " open" : ""}"><button class="nav-i nav-gh" type="button">${ico(SEC_ICON[s.code] || "dot")}<span>${esc(s.name_ar || s.name_en)}</span>${ico("chevron", "chev")}</button>
      <div class="nav-sub">${scr.map(x => link({ route: x.route, title: tOf(x) }, true)).join("")}</div></div>`;
  }
  if (IS_ADMIN) h += `<div class="nav-sep"></div>` + ADMIN_ITEMS.map(a => link(a)).join("");
  return h;
}

// ---------------------------------------------------------------- الهيكل العام (قائمة جانبية + شريط علوي)
const curTheme = () => document.documentElement.dataset.theme === "light" ? "light" : "dark";
const draftCount = () => SUMMARY?.kpis?.draft_entries || 0;

function shell(title, path = "") {
  document.body.classList.remove("login-mode");
  const name = auth.user?.full_name || auth.user?.username || "";
  const initial = [...name.trim()][0] || "؟";
  root.innerHTML = `<div class="app">
    <aside class="sidebar" aria-label="القائمة الرئيسية">
      <a class="brand" href="#/"><img src="/static/company-logos.png?v=20261017" alt="شعارات الشركات"><div class="brand-t">النظام المالي</div></a>
      ${navHtml(path)}
    </aside>
    <div class="content">
      <header class="hdr">
        <button class="icon-btn menu" id="menubtn" type="button" aria-label="القائمة">${ico("menu")}</button>
        <div class="gsearch"><input id="gs" placeholder="البحث العام" autocomplete="off" aria-label="البحث العام"><span class="gs-ico">${ico("search")}</span><div class="gs-res" id="gsr" hidden></div></div>
        <span class="sp"></span>
        <button class="icon-btn" id="themebtn" type="button" title="تبديل الوضع الفاتح/الداكن" aria-label="تبديل الوضع">${ico(curTheme() === "dark" ? "sun" : "moon")}</button>
        <button class="icon-btn" id="bell" type="button" title="القيود غير المرحّلة" aria-label="الإشعارات">${ico("bell")}${draftCount() > 0 ? '<i class="dot"></i>' : ""}</button>
        <span class="avatar" id="profile-avatar" title="${esc(name)}">${esc(initial)}</span><span class="who">${esc(name)}</span>
        <button class="btn sm" id="out" type="button">${ico("logout")}<span>خروج</span></button>
      </header>
      <div class="print-head" id="printhead"></div>
      <div class="pagebar">${title ? `<h2>${esc(title)}</h2>` : ""}<span class="sp"></span><span id="pageact"></span><button class="btn sm" id="printbtn" type="button" hidden>${ico("printer")}<span>طباعة الشاشة</span></button></div>
      <main class="wrap"></main>
    </div>
    <div class="scrim"></div></div>`;
  const $ = s => root.querySelector(s);
  if (auth.user?.avatar_updated_at) userAvatarUrl(auth.user.user_id, auth.user.avatar_updated_at).then(url => {
    const el = $("#profile-avatar"); if (el && url) el.innerHTML = `<img src="${url}" alt="الصورة الشخصية">`;
  }).catch(() => {});
  const app = $(".app");
  root.querySelectorAll(".nav-gh").forEach(b => b.onclick = () => b.parentElement.classList.toggle("open"));
  $("#menubtn").onclick = () => app.classList.toggle("open");
  $(".scrim").onclick = () => app.classList.remove("open");
  $("#printbtn").onclick = () => window.print();
  $("#out").onclick = async () => { try { await api("/auth/logout", { method: "POST" }); } catch {} auth.clear(); resetSession(); location.hash = "#/login"; };
  $("#bell").onclick = () => draftCount() > 0 ? (location.hash = "#/journal") : toast("لا توجد قيود غير مرحّلة");
  $("#themebtn").onclick = () => {
    const t = curTheme() === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = t;
    try { localStorage.setItem("fs_theme", t); } catch {}
    $("#themebtn").innerHTML = ico(t === "dark" ? "sun" : "moon");
  };
  // البحث العام في الشاشات
  const gs = $("#gs"), gr = $("#gsr"), items = navItems();
  gs.oninput = () => {
    const q = gs.value.trim().toLowerCase();
    if (!q) { gr.hidden = true; return; }
    const hits = items.filter(i => (i.title + " " + i.sub).toLowerCase().includes(q)).slice(0, 8);
    gr.innerHTML = hits.length ? hits.map(h => `<a href="#${esc(h.route)}">${esc(h.title)}<small>${esc(h.sub)}</small></a>`).join("") : `<div class="empty">لا توجد نتائج</div>`;
    gr.hidden = false;
  };
  gs.onkeydown = ev => {
    if (ev.key === "Escape") { gr.hidden = true; return; }
    if (ev.key !== "Enter") return;
    const a = gr.querySelector("a");
    if (a) { location.hash = a.getAttribute("href"); gs.value = ""; gr.hidden = true; }
  };
  gs.onblur = () => setTimeout(() => (gr.hidden = true), 150);
  return $("main");
}

function loginPage() {
  resetSession();
  document.body.classList.add("login-mode");
  root.innerHTML = `<form class="login"><h2>تسجيل الدخول</h2>
    <div class="f"><label>اسم المستخدم</label><input name="u" autocomplete="username" required autofocus></div>
    <div class="f"><label>كلمة المرور</label><input name="p" type="password" autocomplete="current-password" required></div>
    <div class="err" id="e"></div><button class="btn primary" style="width:100%">دخول</button></form>`;
  const f = root.querySelector("form");
  f.onsubmit = async ev => {
    ev.preventDefault(); const b = f.querySelector("button"); b.disabled = true;
    try { await login(f.u.value.trim(), f.p.value); location.hash = "#/"; }
    catch (e) { f.querySelector("#e").textContent = errText(e); b.disabled = false; }
  };
}

// ---------------------------------------------------------------- الشاشة الرئيسية
const fmt0 = v => Number(v).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtDate = d => String(d || "").split("-").reverse().join("/");
const compact = v => {
  const a = Math.abs(v);
  const s = a >= 1e9 ? (a / 1e9).toFixed(1) + "B" : a >= 1e6 ? (a / 1e6).toFixed(1) + "M" : a >= 1e3 ? (a / 1e3).toFixed(1) + "K" : String(Math.round(a));
  return (v < 0 ? "-" : "") + s.replace(".0", "");
};
const MONTHS = ["ينا", "فبر", "مار", "أبر", "ماي", "يون", "يول", "أغس", "سبت", "أكت", "نوف", "ديس"];
const ST = { Posted: ["مرحّل", "ok"], Draft: ["مسودة", "warn"], Reversed: ["ملغي", "bad"] };

function niceTicks(min, max, n = 4) {
  if (min === max) { if (min === 0) max = 1; else { min = Math.min(0, min); max = Math.max(0, max); } }
  const raw = (max - min) / n, pow = 10 ** Math.floor(Math.log10(raw)), f = raw / pow;
  const step = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * pow;
  const lo = Math.floor(min / step) * step, hi = Math.ceil(max / step) * step, ticks = [];
  for (let v = lo; v <= hi + step / 2; v += step) ticks.push(+v.toFixed(6));
  return { lo, hi, ticks };
}

function lineChart(series) {      // [{year, month, balance}]
  const W = 640, H = 300, Lm = 92, Rm = 18, T = 30, B = 34;
  const vals = series.map(p => +p.balance);
  const { lo, hi, ticks } = niceTicks(Math.min(0, ...vals), Math.max(0, ...vals));
  const x = i => Lm + i * (W - Lm - Rm) / Math.max(1, series.length - 1);
  const y = v => T + (hi - v) / (hi - lo) * (H - T - B);
  const pts = vals.map((v, i) => [x(i), y(v)]);
  const r = n => n.toFixed(1);
  let d = `M${r(pts[0][0])},${r(pts[0][1])}`;
  for (let i = 0; i < pts.length - 1; i++) {      // منحنى ناعم (Catmull-Rom → Bezier)
    const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
    d += ` C${r(p1[0] + (p2[0] - p0[0]) / 6)},${r(p1[1] + (p2[1] - p0[1]) / 6)} ${r(p2[0] - (p3[0] - p1[0]) / 6)},${r(p2[1] - (p3[1] - p1[1]) / 6)} ${r(p2[0])},${r(p2[1])}`;
  }
  const bottom = y(lo);
  const area = `${d} L${r(pts.at(-1)[0])},${r(bottom)} L${r(pts[0][0])},${r(bottom)} Z`;
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="رصيد الخزينة الشهري">
    <defs><linearGradient id="chg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--brand);stop-opacity:.45"/><stop offset="1" style="stop-color:var(--brand);stop-opacity:.02"/></linearGradient></defs>
    ${ticks.map(t => `<line class="ch-grid" x1="${Lm}" x2="${W - Rm}" y1="${r(y(t))}" y2="${r(y(t))}"/><text class="ch-ax" x="${Lm - 8}" y="${r(y(t) + 4)}" text-anchor="end">${fmt0(t)}</text>`).join("")}
    <path d="${area}" fill="url(#chg)"/><path class="ch-line" d="${d}"/>
    ${pts.map((p, i) => `<circle class="ch-pt" cx="${r(p[0])}" cy="${r(p[1])}" r="3.5"><title>${MONTHS[series[i].month - 1]} ${series[i].year}: ${fmt0(vals[i])}</title></circle><text class="ch-val" x="${r(p[0])}" y="${r(p[1] - 9)}" text-anchor="middle">${compact(vals[i])}</text>`).join("")}
    ${series.map((p, i) => `<text class="ch-ax" x="${r(x(i))}" y="${H - 10}" text-anchor="middle">${MONTHS[p.month - 1]}</text>`).join("")}
  </svg>`;
}

const kpi = (label, icon, val, cls, sub) => `<div class="kpi"><div class="kpi-h">${ico(icon)}<span>${label}</span></div><div class="kpi-v ${cls || ""}"><bdi dir="ltr">${val}</bdi></div><div class="kpi-s">${sub || ""}</div></div>`;

function homeHtml(s) {
  const k = s.kpis, cards = [];
  if (k.total_debit != null) cards.push(kpi("إجمالي المدين", "dollar", fmt0(k.total_debit), "", "القيود المرحّلة"));
  if (k.treasury_balance != null) {
    const v = +k.treasury_balance;
    const others = (s.other_balances || []).map(o => `${esc(o.currency)} ${fmt0(o.balance)}`).join(" · ");
    cards.push(kpi("رصيد الخزينة", "bank", (v > 0 ? "+" : "") + fmt0(v), v > 0 ? "pos" : v < 0 ? "neg" : "", esc(s.currency) + (others ? " · " + others : "")));
  }
  if (k.total_credit != null) cards.push(kpi("إجمالي الدائن", "swap", fmt0(k.total_credit), "", "القيود المرحّلة"));
  if (k.draft_entries != null) cards.push(kpi("عدد القيود غير المرحّلة", "receipt", fmt0(k.draft_entries), "", "مسودات تنتظر الترحيل"));
  const table = s.latest_entries == null ? "" : `<section class="card"><div class="card-h"><h3>آخر القيود</h3>
      <div class="seg"><button class="btn sm primary" type="button" data-f="all">الكل</button><button class="btn sm" type="button" data-f="Draft">مسودة</button></div></div>
      <div class="tbl-wrap"><table><thead><tr><th>رقم القيد</th><th>التاريخ</th><th>البيان</th><th>الحالة</th></tr></thead><tbody id="lastrows"></tbody></table></div></section>`;
  const chart = s.cash_series == null ? "" : `<section class="card"><div class="card-h"><h3>حالة الخزينة</h3><small>رصيد تراكمي بالـ${esc(s.currency)} — آخر 12 شهر</small></div><div class="chart">${lineChart(s.cash_series)}</div></section>`;
  if (!cards.length && !table && !chart) return `<p class="empty">لا توجد بيانات متاحة لصلاحياتك — استخدم القائمة الجانبية للتنقل.</p>`;
  return `<div class="kpis">${cards.join("")}</div><div class="dash">${table}${chart}</div>`;
}

function drawRows(main, entries, only) {
  const tb = main.querySelector("#lastrows"); if (!tb) return;
  const rows = entries.filter(e => only === "all" || e.status === only).slice(0, 8);
  tb.innerHTML = rows.length ? rows.map(e => { const [t, c] = ST[e.status] || [e.status, ""]; return `<tr data-id="${e.journal_entry_id}"><td>${esc(e.entry_no)}</td><td>${fmtDate(e.entry_date)}</td><td>${esc(e.description || "")}</td><td><span class="tag ${c}">${esc(t)}</span></td></tr>`; }).join("")
    : `<tr><td colspan="4" class="empty">لا توجد قيود</td></tr>`;
  tb.querySelectorAll("tr[data-id]").forEach(tr => tr.onclick = () => (location.hash = "#/journal"));
}

async function dashboard() {
  const main = shell("الرئيسية", "/");
  root.querySelector("#pageact").innerHTML = `<button class="btn primary sm" id="refresh" type="button">${ico("refresh")}<span>تحديث</span></button>`;
  main.innerHTML = `<p class="muted">جاري التحميل…</p>`;
  const draw = async () => {
    const s = await api("/dashboard/summary");
    SUMMARY = s;
    const dot = root.querySelector("#bell .dot");
    if (draftCount() > 0 && !dot) root.querySelector("#bell").insertAdjacentHTML("beforeend", '<i class="dot"></i>');
    if (draftCount() === 0 && dot) dot.remove();
    main.innerHTML = homeHtml(s);
    let only = "all";
    drawRows(main, s.latest_entries || [], only);
    main.querySelectorAll(".seg [data-f]").forEach(b => b.onclick = () => {
      only = b.dataset.f;
      main.querySelectorAll(".seg [data-f]").forEach(x => x.classList.toggle("primary", x === b));
      drawRows(main, s.latest_entries || [], only);
    });
  };
  root.querySelector("#refresh").onclick = () => draw().catch(e => toast(errText(e)));
  await draw();
}

// ---------------------------------------------------------------- التوجيه
async function route() {
  let path = (location.hash.replace(/^#/, "") || "/").replace(/\/+$/, "") || "/";
  // توافق مع المسارات القديمة/المختلفة التي قد تكون محفوظة في قاعدة البيانات.
  const routeAliases = { "/financial-checks": "/checks/register", "/checks-register": "/checks/register", "/purchase-cycle": "/purchases", "/purchasing": "/purchases", "/purchase": "/purchases", "/accounting/purchases": "/purchases", "/accounting/purchase-cycle": "/purchases", "/purchase-orders": "/purchases", "/purchase-order": "/purchases" };
  if (routeAliases[path] || /\/(purchase|purchases|purchasing|purchase-cycle|purchase-order|purchase-orders)$/i.test(path)) {
    path = routeAliases[path] || "/purchases";
    history.replaceState(null, "", "#" + path);
  }
  if (path === "/login") return loginPage();
  if (!auth.loggedIn) return (location.hash = "#/login");
  try {
    await ensureNav();
    if (path === "/") return await dashboard();
    const loader = SCREENS[path];
    if (!loader) { shell(titleOf(path), path).innerHTML = `<p>هذه الشاشة قيد التنفيذ.</p><button class="btn" onclick="location.hash='#/'">رجوع</button>`; return; }
    const mod = await loader();
    const main = shell(titleOf(path), path);
    await mod.render(main, { api, auth, route: path });
    mountDataExchange(main, api, path);
    root.querySelector("#printbtn").hidden = false;     // طباعة أي شاشة (الرئيسية والدخول مالهمش طباعة)
  } catch (e) { toast(errText(e)); }
}
addEventListener("hashchange", route);
route();

// ترويسة الطباعة: اسم الشاشة + التاريخ + المستخدم (بتظهر في الورق بس)
addEventListener("beforeprint", () => {
  const h = document.getElementById("printhead"); if (!h) return;
  const t = document.querySelector(".pagebar h2, main .pagehead h2, main h2, main .sec > h3, main h3")?.textContent?.trim() || document.title;
  h.innerHTML = `<b>${esc(t)}</b><span>${esc(new Date().toLocaleString("ar-EG"))}${auth.user?.full_name ? " — " + esc(auth.user.full_name) : ""}</span>`;
});
