def test_health_and_ui(client):
    assert client.get("/health").json() == {"status": "ok"}
    r = client.get("/"); assert r.status_code == 200 and "app.js" in r.text
    assert "no-store" in r.headers["cache-control"] and r.headers["pragma"] == "no-cache"
    asset = client.get("/static/pages/accounts.js")
    assert asset.status_code == 200 and "no-cache" in asset.headers["cache-control"]

def test_login_fail(client):
    assert client.post("/auth/login", json={"username": "admin", "password": "x"}).status_code == 401

def test_dashboard_and_me(client, hdr):
    d = client.get("/dashboard", headers=hdr).json()
    assert d["screens_count"] == sum(len(section["screens"]) for section in d["sections"])
    assert "/accounts" in [x["route"] for s in d["sections"] for x in s["screens"]]
    assert {"screen": "ChartOfAccounts", "action": "Print"} in client.get("/auth/me", headers=hdr).json()["permissions"]


def test_permission_sync_is_idempotent(client):
    from sqlalchemy import select
    from app import bootstrap
    from app.database import SessionLocal
    from app.models import RolePermission

    with SessionLocal() as db:
        before = db.execute(select(RolePermission.role_id, RolePermission.permission_id)).all()
        bootstrap.sync_permissions(db)
        bootstrap.sync_permissions(db)
        after = db.execute(select(RolePermission.role_id, RolePermission.permission_id)).all()
    assert len(after) == len(set(after))
    assert set(after) == set(before)

def test_accounts_crud(client, hdr):
    from uuid import uuid4
    suffix = uuid4().hex[:8].upper()
    assert client.get("/accounts").status_code == 401
    a = client.post("/accounts", headers=hdr, json={"account_code": f"T-{suffix}", "account_name_ar": f"الأصول {suffix}", "classification_id": 1, "normal_balance": "DR"})
    assert a.status_code == 201, a.text
    b = client.post("/accounts", headers=hdr, json={"account_code": f"T-{suffix}-1", "account_name_ar": f"الخزينة {suffix}", "classification_id": 1,
                    "normal_balance": "DR", "parent_account_id": a.json()["account_id"], "opening_debit": "1500.50"})
    assert b.status_code == 201
    assert client.get(f"/accounts?q={suffix}", headers=hdr).json()["total"] == 2
    assert client.delete(f"/accounts/{a.json()['account_id']}", headers=hdr).status_code == 409
    assert client.get("/accounts/export/pdf", headers=hdr).content[:4] == b"%PDF"
    assert client.get("/accounts/import/template", headers=hdr).status_code == 200


def test_login_rejects_wrong_password(client):
    r = client.post("/auth/login", json={"username": "admin", "password": "wrong-password"})
    assert r.status_code == 401


def test_login_resets_failed_count_after_success(client):
    from app.database import SessionLocal
    from app.models import User
    from sqlalchemy import select
    with SessionLocal() as db:
        user = db.scalar(select(User).where(User.username == "admin"))
        user.failed_login_count = 2
        db.commit()
    r = client.post("/auth/login", json={"username": "admin", "password": "ValidPassw0rd!2026"})
    assert r.status_code == 200
    with SessionLocal() as db:
        user = db.scalar(select(User).where(User.username == "admin"))
        assert user.failed_login_count == 0 and user.locked_until is None
