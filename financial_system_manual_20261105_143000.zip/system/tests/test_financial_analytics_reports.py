from uuid import uuid4

from app.database import SessionLocal
from app.models import AccountClassification


def test_financial_analytics_reports(client, hdr):
    suffix = uuid4().hex[:10]
    with SessionLocal() as db:
        classification = AccountClassification(name_ar=f"تصنيف قائمة دخل {suffix}", statement_type="IncomeStatement")
        db.add(classification)
        db.commit()
        classification_id = classification.classification_id

    project_response = client.post("/projects", headers=hdr, json={"name_ar": f"مشروع تقارير {suffix}"})
    assert project_response.status_code == 201, project_response.text
    project_id = project_response.json()["project_id"]

    def account(code, name, normal_balance):
        response = client.post("/accounts", headers=hdr, json={"account_code": code,
            "account_name_ar": name, "classification_id": classification_id,
            "normal_balance": normal_balance})
        assert response.status_code == 201, response.text
        return response.json()["account_id"]

    expense_id = account(f"RPT-E-{suffix}", "مصروف تقرير", "DR")
    revenue_id = account(f"RPT-R-{suffix}", "إيراد تقرير", "CR")
    assert client.post("/journal/fiscal-years", headers=hdr, json={
        "start_date": "2035-01-01", "end_date": "2035-12-31"}).status_code == 201
    entry = client.post("/journal", headers=hdr, json={"entry_date": "2035-01-15",
        "description": "قيد تقرير اختبار", "lines": [
            {"account_id": expense_id, "project_id": project_id, "debit_amount": "120", "description": "مصروف المشروع"},
            {"account_id": revenue_id, "project_id": project_id, "credit_amount": "120", "description": "إيراد المشروع"}]})
    assert entry.status_code == 201, entry.text
    assert client.post(f"/journal/{entry.json()['journal_entry_id']}/post", headers=hdr).status_code == 200

    ledger = client.get("/api/reports/account-ledger", headers=hdr, params={
        "account_id": expense_id, "date_from": "2035-02-01", "date_to": "2035-02-28", "project_id": project_id})
    assert ledger.status_code == 200, ledger.text
    assert ledger.json()["opening_balance"] == "120.00"
    assert ledger.json()["closing_balance"] == "120.00" and ledger.json()["items"] == []

    project_report = client.get("/api/reports/project-financials", headers=hdr,
        params={"date_from": "2035-01-01", "date_to": "2035-01-31", "project_id": project_id})
    assert project_report.status_code == 200, project_report.text
    item = project_report.json()["items"][0]
    assert item["revenue"] == "120.00" and item["expenses"] == "120.00" and item["net"] == "0.00"

    for url in ("/api/reports/financial-lookups", "/api/reports/cash-flow", "/api/reports/aging?as_of=2035-02-01"):
        response = client.get(url, headers=hdr)
        assert response.status_code == 200, f"{url}: {response.text}"
    assert client.get("/api/reports/cash-flow").status_code == 401
