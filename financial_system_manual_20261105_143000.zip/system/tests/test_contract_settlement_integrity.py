"""Focused regression tests for settlement arithmetic used before GL posting."""
from decimal import Decimal, ROUND_HALF_UP


def money(value):
    return Decimal(str(value or 0)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def expected_net(work, vat, deductions):
    return money(Decimal(str(work)) + Decimal(str(vat)) - sum((money(v) for v in deductions), Decimal("0.00")))


def test_customer_settlement_net_and_journal_balance_with_vat_and_deductions():
    # Customer posting: Dr net receivable + Dr withholding/retention assets;
    # Cr revenue + Cr output VAT.
    work, vat, deductions = Decimal("1000.00"), Decimal("150.00"), [Decimal("100.00"), Decimal("25.00")]
    net = expected_net(work, vat, deductions)
    assert net == Decimal("1025.00")
    assert money(net + sum(deductions)) == money(work + vat)


def test_subcontractor_settlement_net_and_journal_balance_with_vat_and_deductions():
    # Subcontractor posting: Dr project cost + Dr input VAT;
    # Cr net payable + Cr retention/tax/advance balances.
    work, vat, deductions = Decimal("1000.00"), Decimal("150.00"), [Decimal("100.00"), Decimal("25.00")]
    net = expected_net(work, vat, deductions)
    assert net == Decimal("1025.00")
    assert money(work + vat) == money(net + sum(deductions))


def test_negative_or_mismatched_net_is_rejected_by_integrity_rule():
    work, vat, deductions = Decimal("1000.00"), Decimal("150.00"), [Decimal("100.00")]
    expected = expected_net(work, vat, deductions)
    assert expected == Decimal("1050.00")
    assert expected != money("1049.99")
    assert expected_net(work, vat, [Decimal("1200.00")]) < 0
