from datetime import date

def _contract(client, hdr, no, value="1000"):
    r = client.post("/api/contracts", headers=hdr, json={
        "contract_no": no, "title": "اختبار مستخلصات", "client_name": "عميل اختبار",
        "original_value": value, "status": "Active"
    })
    assert r.status_code == 201, r.text
    contract_id = r.json()["contract_id"]
    # Contract creation queues engineering approval; activation requires both reviewers.
    assert r.json()["status"] == "PendingEngineering"
    engineering = client.post(f"/api/contracts/{contract_id}/engineering-approve", headers=hdr)
    assert engineering.status_code == 200 and engineering.json()["status"] == "PendingFinancial"
    assert client.post(f"/api/contracts/{contract_id}/approve", headers=hdr).status_code == 200
    return contract_id


def _item(client, hdr, contract_id, no="1", quantity="10", price="100"):
    r = client.post(f"/api/contracts-erp/{contract_id}/technical-items", headers=hdr, json={
        "item_no": no, "description": "أعمال خرسانة", "unit": "م3",
        "quantity": quantity, "unit_price": price
    })
    assert r.status_code == 201, r.text
    return r.json()["item_id"]


def _settlement(client, hdr, contract_id, no, item_id, qty):
    return client.post(f"/api/contracts-erp/{contract_id}/settlements", headers=hdr, json={
        "settlement_side": "Customer", "settlement_no": no, "settlement_date": "2030-03-01",
        "counterparty_name": "عميل اختبار", "items": [{"contract_item_id": item_id, "quantity": qty}],
        "vat_rate": 0
    })


def test_contract_settlement_cumulative_and_duplicate_quantity_guard(client, hdr):
    contract_id = _contract(client, hdr, "CT-QUANTITY-TEST-01")
    item_id = _item(client, hdr, contract_id)

    first = _settlement(client, hdr, contract_id, "S-001", item_id, "6")
    assert first.status_code == 201, first.text
    assert first.json()["work_value"] == "600.00"

    assert first.json()["status"] == "PendingApproval"

    # Settlements awaiting approval must not inflate previous/cumulative figures.
    summary = client.get(f"/api/contracts-erp/{contract_id}/settlement-summary?settlement_side=Customer", headers=hdr)
    assert summary.status_code == 200, summary.text
    assert summary.json()["previous_settlements"] == "0.00"
    assert summary.json()["items"][0]["previous_quantity"] == "0.00"

    assert client.post(f"/api/contracts-erp/settlements/{first.json()['settlement_id']}/approve", headers=hdr).status_code == 200
    summary = client.get(f"/api/contracts-erp/{contract_id}/settlement-summary?settlement_side=Customer", headers=hdr).json()
    assert summary["previous_settlements"] == "600.00"
    assert summary["cumulative_work_value"] == "600.00"
    assert summary["remaining_contract_value"] == "400.00"
    assert summary["items"][0]["previous_quantity"] == "6.0000"
    assert summary["items"][0]["remaining_quantity"] == "4.0000"

    # Over-billing remaining item quantity is rejected at creation.
    too_much = _settlement(client, hdr, contract_id, "S-002", item_id, "5")
    assert too_much.status_code == 409, too_much.text

    # Multiple settlements can await approval, but approval revalidates quantities under lock.
    second = _settlement(client, hdr, contract_id, "S-003", item_id, "4")
    third = _settlement(client, hdr, contract_id, "S-004", item_id, "4")
    assert second.status_code == 201, second.text
    assert third.status_code == 201, third.text
    assert client.post(f"/api/contracts-erp/settlements/{second.json()['settlement_id']}/approve", headers=hdr).status_code == 200
    blocked = client.post(f"/api/contracts-erp/settlements/{third.json()['settlement_id']}/approve", headers=hdr)
    assert blocked.status_code == 409, blocked.text

    # The older aggregate-only endpoint cannot bypass the item-based workflow.
    old_manual = client.post(f"/api/contracts/{contract_id}/billings", headers=hdr, json={
        "billing_no": "OLD-001", "billing_date": "2030-03-02", "work_value": "1",
        "retention_amount": "0", "advance_deduction": "0", "other_deductions": "0", "status": "Draft"
    })
    assert old_manual.status_code == 409, old_manual.text

    # Legacy/manual work_value input is no longer accepted once technical items exist.
    manual = client.post(f"/api/contracts-erp/{contract_id}/settlements", headers=hdr, json={
        "settlement_side": "Customer", "settlement_no": "S-005", "settlement_date": "2030-03-02",
        "counterparty_name": "عميل اختبار", "work_value": "1", "vat_rate": 0
    })
    assert manual.status_code == 422, manual.text


def test_contract_activation_requires_explicit_approval(client, hdr):
    created = client.post("/api/contracts", headers=hdr, json={
        "contract_no": "CT-LIFECYCLE-TEST", "title": "دورة اعتماد", "client_name": "عميل اختبار",
        "original_value": "500", "status": "Active"
    })
    assert created.status_code == 201, created.text
    contract_id = created.json()["contract_id"]
    assert created.json()["contract_no"] == f"CT-{date.today().year}-{contract_id:06d}"
    assert created.json()["status"] == "PendingEngineering"
    active_list = client.get("/api/contracts", headers=hdr)
    assert active_list.status_code == 200
    assert all(x["status"].lower() == "active" for x in active_list.json()["items"])
    assert all(x["contract_id"] != contract_id for x in active_list.json()["items"])
    assert client.post(f"/api/contracts/{contract_id}/approve", headers=hdr).status_code == 409
    engineering = client.post(f"/api/contracts/{contract_id}/engineering-approve", headers=hdr)
    assert engineering.status_code == 200 and engineering.json()["status"] == "PendingFinancial"
    approved = client.post(f"/api/contracts/{contract_id}/approve", headers=hdr)
    assert approved.status_code == 200 and approved.json()["status"] == "Active"
    assert client.get("/api/contracts", headers=hdr).json()["items"]
