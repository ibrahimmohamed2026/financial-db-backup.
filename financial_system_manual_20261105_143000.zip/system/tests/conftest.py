import os
import tempfile
os.environ.setdefault("BACKUP_DIR", tempfile.mkdtemp(prefix="fs_backups_"))
os.environ.setdefault("BACKUP_AUTO_ENABLED", "false")
os.environ.setdefault("BACKUP_SETTINGS_FILE", os.path.join(tempfile.mkdtemp(prefix="fs_bset_"), "backup_settings.json"))
os.environ.setdefault("DATABASE_URL", "sqlite:///file:fs_test?mode=memory&cache=shared&uri=true")
os.environ.setdefault("JWT_SECRET", "test-secret-test-secret-test-secret-123")
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text, StaticPool
from app import bootstrap, database
from app.main import app
from app.models import AccountClassification, Base


@pytest.fixture(scope="session")
def client():
    eng = database.engine
    Base.metadata.create_all(eng)
    with eng.begin() as c:
        c.execute(text("""CREATE VIEW vw_EffectivePermissions AS
          SELECT u.UserId, p.PermissionId, p.ScreenCode, p.ActionCode,
          CASE WHEN up.IsAllowed IS NOT NULL THEN up.IsAllowed WHEN rp.PermissionId IS NOT NULL THEN 1 ELSE 0 END AS IsAllowed
          FROM Users u CROSS JOIN Permissions p
          LEFT JOIN UserRoles ur ON ur.UserId=u.UserId
          LEFT JOIN RolePermissions rp ON rp.RoleId=ur.RoleId AND rp.PermissionId=p.PermissionId
          LEFT JOIN UserPermissions up ON up.UserId=u.UserId AND up.PermissionId=p.PermissionId"""))
    with database.SessionLocal() as s:
        s.add_all([AccountClassification(name_ar="أصول متداولة", statement_type="BalanceSheet"),
                   AccountClassification(name_ar="نقدية بالصندوق و البنوك", statement_type="BalanceSheet")]); s.commit()
        bootstrap.seed_screens(s); bootstrap.sync_permissions(s); bootstrap.create_admin(s, "admin", "ValidPassw0rd!2026")
    return TestClient(app)


@pytest.fixture(scope="session")
def hdr(client):
    t = client.post("/auth/login", json={"username": "admin", "password": "ValidPassw0rd!2026"}).json()
    return {"Authorization": "Bearer " + t["access_token"]}
