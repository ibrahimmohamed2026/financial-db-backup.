from uuid import uuid4
from datetime import date

from sqlalchemy import delete, select

from app import database
from app.models import Account, AccountClassification, Company, Counterparty, FiscalYear, Base, TreasuryAccount


def test_purchase_order_approval_and_receipt_updates_stock_once(client, hdr):
    token = uuid4().hex[:10].upper()
    warehouse = client.post('/api/inventory/warehouses', headers=hdr, json={
        'code': f'PWH-{token}', 'name': 'مخزن اختبار المشتريات'
    })
    item = client.post('/api/inventory/items', headers=hdr, json={
        'code': f'PIT-{token}', 'name': 'صنف اختبار المشتريات', 'unit': 'طن'
    })
    assert warehouse.status_code == 201, warehouse.text
    assert item.status_code == 201, item.text

    order = client.post('/api/purchases', headers=hdr, json={
        'order_no': f'PO-{token}', 'order_date': '2030-06-01',
        'supplier_name': 'مورد اختبار', 'warehouse_id': warehouse.json()['warehouse_id'],
        'lines': [{'item_id': item.json()['item_id'], 'quantity': 12, 'unit_price': 25}]
    })
    assert order.status_code == 201, order.text
    order_id = order.json()['purchase_order_id']
    assert order.json()['order_no'] == f"PO-2030-{order_id:06d}"
    assert order.json()['order_no'] != f'PO-{token}'
    assert order.json()['total_amount'] == '300'

    listed = client.get('/api/purchases', headers=hdr)
    assert listed.status_code == 200, listed.text
    found = next(x for x in listed.json()['items'] if x['purchase_order_id'] == order_id)
    assert found['status'] == 'Draft' and found['lines'][0]['quantity'] == '12.000'

    approved = client.post(f'/api/purchases/{order_id}/approve', headers=hdr)
    assert approved.status_code == 200, approved.text
    pending_receipts = client.get('/api/inventory/purchase-receipts', headers=hdr)
    assert pending_receipts.status_code == 200, pending_receipts.text
    assert any(x['purchase_order_id'] == order_id for x in pending_receipts.json()['items'])
    received = client.post(f'/api/purchases/{order_id}/receive', headers=hdr)
    assert received.status_code == 200, received.text
    pending_receipts = client.get('/api/inventory/purchase-receipts', headers=hdr)
    assert pending_receipts.status_code == 200, pending_receipts.text
    assert all(x['purchase_order_id'] != order_id for x in pending_receipts.json()['items'])
    duplicate_receive = client.post(f'/api/purchases/{order_id}/receive', headers=hdr)
    assert duplicate_receive.status_code == 409, duplicate_receive.text

    inventory = client.get('/api/inventory/items', headers=hdr)
    assert inventory.status_code == 200, inventory.text
    found_item = next(x for x in inventory.json()['items'] if x['item_id'] == item.json()['item_id'])
    assert found_item['quantity'] == '12.000'

    # Keep the shared test database clean for other tests.
    with database.engine.begin() as conn:
        movement_ids = select(Base.metadata.tables['InventoryMovements'].c.MovementId).where(
            Base.metadata.tables['InventoryMovements'].c.Reference == order.json()['order_no']
        )
        conn.execute(delete(Base.metadata.tables['InventoryMovements']).where(
            Base.metadata.tables['InventoryMovements'].c.MovementId.in_(movement_ids)
        ))
        conn.execute(delete(Base.metadata.tables['PurchaseOrderLines']).where(
            Base.metadata.tables['PurchaseOrderLines'].c.PurchaseOrderId == order_id
        ))
        conn.execute(delete(Base.metadata.tables['PurchaseOrders']).where(
            Base.metadata.tables['PurchaseOrders'].c.PurchaseOrderId == order_id
        ))
        conn.execute(delete(Base.metadata.tables['AuditLog']).where(
            Base.metadata.tables['AuditLog'].c.EntityId == str(order_id)
        ))
        conn.execute(delete(Base.metadata.tables['InventoryItems']).where(
            Base.metadata.tables['InventoryItems'].c.ItemId == item.json()['item_id']
        ))
        conn.execute(delete(Base.metadata.tables['InventoryWarehouses']).where(
            Base.metadata.tables['InventoryWarehouses'].c.WarehouseId == warehouse.json()['warehouse_id']
        ))


def test_supplier_invoice_is_journaled_once_and_payment_is_balanced(client, hdr):
    token=uuid4().hex[:10].upper()
    with database.SessionLocal() as db:
        classification=db.query(AccountClassification).first()
        inventory_account=Account(account_code=f"T{token[:8]}",account_name_ar="مخزون/مصروف اختبار",classification_id=classification.classification_id,normal_balance="DR",is_active=True)
        payable_account=Account(account_code=f"P{token[:8]}",account_name_ar="مورد اختبار دائن",classification_id=classification.classification_id,normal_balance="CR",is_active=True)
        cash_account=Account(account_code=f"C{token[:8]}",account_name_ar="بنك اختبار",classification_id=classification.classification_id,normal_balance="DR",is_active=True)
        company=Company(name_ar=f"شركة اختبار {token}")
        db.add_all([inventory_account,payable_account,cash_account,company]);db.flush()
        fy=FiscalYear(company_id=company.company_id,start_date=date(2030,1,1),end_date=date(2030,12,31),is_closed=False)
        bank=TreasuryAccount(name_ar=f"بنك اختبار {token}",account_type="Bank",currency_code="EGP",gl_account_id=cash_account.account_id,is_active=True)
        db.add_all([fy,bank]);db.commit()
        account_ids=(inventory_account.account_id,payable_account.account_id,cash_account.account_id)
        fy_id=fy.fiscal_year_id;bank_id=bank.treasury_account_id

    warehouse=client.post('/api/inventory/warehouses',headers=hdr,json={'code':f'IWH-{token}','name':'مخزن فاتورة اختبار'})
    item=client.post('/api/inventory/items',headers=hdr,json={'code':f'IIT-{token}','name':'صنف فاتورة اختبار'})
    po=client.post('/api/purchases',headers=hdr,json={'order_date':'2030-03-01','supplier_name':f'مورد فاتورة {token}',
        'warehouse_id':warehouse.json()['warehouse_id'],'lines':[{'item_id':item.json()['item_id'],'quantity':'2','unit_price':'10'}]})
    order_id=po.json()['purchase_order_id']
    assert client.post(f'/api/purchases/{order_id}/approve',headers=hdr).status_code==200
    assert client.post(f'/api/purchases/{order_id}/receive',headers=hdr).status_code==200
    listed=next(x for x in client.get('/api/purchases',headers=hdr).json()['items'] if x['purchase_order_id']==order_id)
    line_id=listed['lines'][0]
    with database.SessionLocal() as db:
        supplier=db.query(Counterparty).filter(Counterparty.legal_name==f'مورد فاتورة {token}').one()
        supplier.linked_account_id=account_ids[1];db.commit()
    payload={'invoice_no':f'INV-{token}','invoice_date':'2030-03-02','purchase_order_id':order_id,
        'tax_amount':'2','tax_account_id':account_ids[0],
        'lines':[{'purchase_order_line_id':line_id['line_id'],'account_id':account_ids[0],'quantity':'2','unit_price':'10'}]}
    invoice=client.post('/api/purchases/invoices',headers=hdr,json=payload)
    assert invoice.status_code==201,invoice.text
    invoice_id=invoice.json()['invoice_id']
    assert invoice.json()['total_amount']=='22.00'
    assert client.post(f'/api/purchases/invoices/{invoice_id}/approve',headers=hdr).status_code==200
    posted=client.post(f'/api/purchases/invoices/{invoice_id}/post',headers=hdr)
    assert posted.status_code==200,posted.text
    assert client.post(f'/api/purchases/invoices/{invoice_id}/post',headers=hdr).status_code==409
    with database.SessionLocal() as db:
        entry=db.query(Base.metadata.tables['JournalEntries']).filter_by(JournalEntryId=posted.json()['journal_entry_id']).one()
        details=db.query(Base.metadata.tables['JournalEntryDetails']).filter_by(JournalEntryId=posted.json()['journal_entry_id']).all()
        assert entry.Status=='Posted'
        assert sum(x.DebitAmount for x in details)==sum(x.CreditAmount for x in details)==22
    payment=client.post(f'/api/purchases/invoices/{invoice_id}/payments',headers=hdr,json={'treasury_account_id':bank_id,
        'transaction_date':'2030-03-03','amount':'7'})
    assert payment.status_code==201,payment.text
    assert payment.json()['remaining_amount']=='15.00'
    with database.SessionLocal() as db:
        payment_details=db.query(Base.metadata.tables['JournalEntryDetails']).filter_by(JournalEntryId=payment.json()['journal_entry_id']).all()
        assert sum(x.DebitAmount for x in payment_details)==sum(x.CreditAmount for x in payment_details)==7
