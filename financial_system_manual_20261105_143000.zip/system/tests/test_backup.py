import io
import json
import zipfile
from datetime import datetime

from app import backup_service as svc
from app.config import settings
from app.database import SessionLocal
from app.models import Project


def _names(zbytes: bytes):
    return set(zipfile.ZipFile(io.BytesIO(zbytes)).namelist())


def test_manual_backup_download_has_db_and_system_files(client, hdr):
    r = client.get("/admin/backup", headers=hdr)
    assert r.status_code == 200 and r.headers["content-type"] == "application/zip"
    names = _names(r.content)
    assert {"manifest.json", "database/Users.jsonl", "database/ChartOfAccounts.jsonl", "system/app/main.py"} <= names
    assert not any(n.endswith(".env") for n in names)          # الأسرار مش بتتضمّن
    manifest = json.loads(zipfile.ZipFile(io.BytesIO(r.content)).read("manifest.json"))
    assert manifest["tables"]["Users"] >= 1


def test_backup_requires_auth(client):
    assert client.get("/admin/backup").status_code in (401, 403)
    assert client.get("/admin/backup/status").status_code in (401, 403)


def test_save_only_and_list_and_download_saved(client, hdr):
    r = client.post("/admin/backup/run", headers=hdr)
    assert r.status_code == 200
    name = r.json()["name"]
    st = client.get("/admin/backup/status", headers=hdr).json()
    assert name in [b["name"] for b in st["backups"]] and st["backup_dir"]
    assert client.get(f"/admin/backup/download/{name}", headers=hdr).status_code == 200
    assert client.get("/admin/backup/download/..%2F..%2Fetc%2Fpasswd", headers=hdr).status_code in (400, 404)
    assert client.get("/admin/backup/download/not_a_backup.zip", headers=hdr).status_code == 400


def test_restore_requires_confirmation_and_valid_zip(client, hdr):
    files = {"file": ("x.zip", b"not a zip", "application/zip")}
    assert client.post("/admin/backup/restore", headers=hdr, files=files).status_code == 400      # بدون confirm
    r = client.post("/admin/backup/restore", headers=hdr, files=files, data={"confirm": "yes"})
    assert r.status_code == 400
    empty = io.BytesIO()
    with zipfile.ZipFile(empty, "w") as z:
        z.writestr("hello.txt", "x")
    r = client.post("/admin/backup/restore", headers=hdr, data={"confirm": "yes"},
                    files={"file": ("y.zip", empty.getvalue(), "application/zip")})
    assert r.status_code == 400


def test_restore_roundtrip_removes_later_changes(client, hdr):
    backup = client.get("/admin/backup", headers=hdr).content
    with SessionLocal() as s:
        s.add(Project(name_ar="مشروع بعد النسخة")); s.commit()
    r = client.post("/admin/backup/restore", headers=hdr, data={"confirm": "yes"},
                    files={"file": ("b.zip", backup, "application/zip")})
    assert r.status_code == 200, r.text
    assert r.json()["safety_backup"].startswith("financial_system_pre_restore_")
    with SessionLocal() as s:
        assert s.query(Project).filter_by(name_ar="مشروع بعد النسخة").count() == 0
    # المستخدم لسه موجود وبيقدر يسجّل دخول بعد الاستعادة
    assert client.post("/auth/login", json={"username": "admin", "password": "ValidPassw0rd!2026"}).status_code == 200


def test_daily_scheduler_runs_once_after_time_and_prunes(monkeypatch):
    monkeypatch.setattr(settings, "backup_time", "02:00")
    monkeypatch.setattr(settings, "backup_retention", 2)
    assert svc.run_due_auto_backup(datetime(2030, 1, 1, 1, 59)) is None          # قبل الميعاد
    first = svc.run_due_auto_backup(datetime(2030, 1, 1, 2, 1))
    assert first is not None and first.name.startswith("financial_system_auto_")
    assert svc.run_due_auto_backup(datetime(2030, 1, 1, 23, 0)) is None          # مرة واحدة في اليوم
    for _ in range(3):
        svc.create_backup("auto")
    assert len([b for b in svc.list_backups() if b["kind"] == "auto"]) == 2      # الاحتفاظ بآخر 2 بس


def test_change_backup_location_from_ui(client, hdr, tmp_path, monkeypatch):
    for k in ("backup_dir", "backup_auto_enabled", "backup_time", "backup_retention"):
        monkeypatch.setattr(settings, k, getattr(settings, k))          # عشان يتسترجعوا بعد الاختبار
    new_dir = tmp_path / "other_place"
    body = {"backup_dir": str(new_dir), "auto_enabled": False, "auto_time": "03:30", "retention": 5}
    try:
        r = client.put("/admin/backup/settings", headers=hdr, json=body)
        assert r.status_code == 200, r.text
        assert r.json()["backup_dir"] == str(new_dir) and r.json()["auto_time"] == "03:30" and r.json()["retention"] == 5
        name = client.post("/admin/backup/run", headers=hdr).json()["name"]
        assert (new_dir / name).is_file()                                  # النسخة اتحفظت في المكان الجديد
        assert client.put("/admin/backup/settings", headers=hdr, json={**body, "auto_time": "25:00"}).status_code == 400
        assert client.put("/admin/backup/settings", headers=hdr, json={**body, "backup_dir": ""}).status_code == 400
    finally:
        svc._settings_file().unlink(missing_ok=True)
