import io

import pytest

from app.arabic_money import amount_in_words


@pytest.mark.parametrize("amount,expected", [
    ("50.25", "خمسون جنيهًا وخمسة وعشرون قرشًا فقط لا غير"),
    ("0.50", "خمسون قرشًا فقط لا غير"),
    ("1", "جنيه واحد فقط لا غير"),
    ("2", "جنيهان فقط لا غير"),
    ("200", "مائتا جنيه فقط لا غير"),
    ("2000", "ألفا جنيه فقط لا غير"),
    ("11000", "أحد عشر ألف جنيه فقط لا غير"),
    ("12345.67", "اثنا عشر ألفًا وثلاثمائة وخمسة وأربعون جنيهًا وسبعة وستون قرشًا فقط لا غير"),
    ("1000002", "مليون وجنيهان فقط لا غير"),
    ("0", "صفر جنيه فقط لا غير"),
])
def test_amount_words(amount, expected):
    assert amount_in_words(amount) == expected


def test_amount_words_usd_and_invalid():
    assert amount_in_words("3.01", "USD") == "ثلاثة دولارات وسنت واحد فقط لا غير"
    for bad in ("-1", "abc", "NaN", "1e20"):
        with pytest.raises(ValueError):
            amount_in_words(bad)
    with pytest.raises(ValueError):
        amount_in_words(1, "EUR")


def _gl(client, hdr, code, name):
    r = client.post("/accounts", headers=hdr, json={"account_code": code, "account_name_ar": name,
                    "classification_id": 2, "normal_balance": "DR"})
    assert r.status_code == 201, r.text
    return r.json()["account_id"]


def _bank(client, hdr, screen, checks_screen, name, acc_no, gl, cur="EGP"):
    r = client.post(f"/treasury/{screen}/account", headers=hdr, json={
        "name_ar": name, "account_type": "Bank", "currency_code": cur, "bank_account_number": acc_no, "gl_account_id": gl})
    assert r.status_code == 201, r.text
    tid = r.json()["treasury_account_id"]
    assert client.post(f"/checks/{checks_screen}/account", headers=hdr, json={"treasury_account_id": tid}).status_code == 200
    return tid


def test_checks_filters_search_and_export(client, hdr):
    from openpyxl import load_workbook

    # بنكين بأرقام حسابات متشابهة: 110205 و 1102055 (التطابق لازم يكون كامل)
    _bank(client, hdr, "BankCairoEgp", "ChecksCairoEgp", "بنك القاهرة", "110205", _gl(client, hdr, "F100", "بنك ف1"))
    _bank(client, hdr, "BankCibUsd", "ChecksCairoUsd", "بنك دولار", "1102055", _gl(client, hdr, "F200", "بنك ف2"), "USD")
    b1 = client.post("/checks/beneficiaries", headers=hdr, json={"name_ar": "شركة النور", "bank_account_number": "998877"}).json()["beneficiary_id"]
    b2 = client.post("/checks/beneficiaries", headers=hdr, json={"name_ar": "=HYPERLINK(\"x\")", "bank_account_number": "55"}).json()["beneficiary_id"]

    def add(sc, seq, no, ben, amount):
        r = client.post(f"/checks/{sc}/items", headers=hdr, json={
            "check_book_no": "F", "sequence_no": seq, "check_no": no, "beneficiary_id": ben, "amount": amount})
        assert r.status_code == 201, r.text

    add("ChecksCairoEgp", 1, "7001", b1, "50.25")
    add("ChecksCairoEgp", 2, "7002", b2, "100")
    add("ChecksCairoUsd", 1, "8001", b1, "3.01")

    # التفقيط يظهر في القائمة وبعملة الدفتر
    r = client.get("/checks/ChecksCairoEgp/items", headers=hdr).json()
    assert {i["amount_words"] for i in r["items"]} == {"خمسون جنيهًا وخمسة وعشرون قرشًا فقط لا غير", "مائة جنيه فقط لا غير"}
    assert client.get("/checks/amount-words", headers=hdr, params={"amount": "50.25"}).json()["amount_words"].startswith("خمسون جنيهًا")
    assert client.get("/checks/amount-words", headers=hdr, params={"amount": "x"}).status_code == 422

    # رقم الحساب: تطابق كامل، مش جزء
    s = lambda **p: client.get("/checks/search", headers=hdr, params=p).json()
    assert {i["check_no"] for i in s(account_no="110205")["items"]} == {"7001", "7002"}
    assert {i["check_no"] for i in s(account_no="1102055")["items"]} == {"8001"}
    assert s(account_no="11020")["items"] == []                       # جزء من الرقم ما يطابقش
    assert {i["check_no"] for i in s(account_no="998877")["items"]} == {"7001", "8001"}  # رقم حساب المستفيد
    # باقي الفلاتر
    assert [i["check_no"] for i in s(check_no="7002")["items"]] == ["7002"]
    assert s(check_no="700")["items"] == []
    assert {i["check_no"] for i in s(beneficiary="النور")["items"]} == {"7001", "8001"}
    assert {i["check_no"] for i in s(status="جديد", account_no="110205")["items"]} == {"7001", "7002"}
    assert s(status="مطبوع")["items"] == []
    # دفتر محدد: ما يخلطش شيكات بنك ببنك تاني
    assert {i["check_no"] for i in s(screen="ChecksCairoEgp", beneficiary="النور")["items"]} == {"7001"}
    assert s(screen="ChecksCairoEgp", account_no="1102055")["items"] == []
    assert client.get("/checks/search", headers=hdr, params={"screen": "Nope"}).status_code == 404
    # الملخص مفصول بالعملة
    cur = {(x["currency_code"], x["amount"]) for x in s(beneficiary="النور")["summary"]}
    assert cur == {("EGP", "50.25"), ("USD", "3.01")}
    # % و _ حروف عادية في البحث مش wildcard
    assert s(beneficiary="%")["items"] == []

    # تصدير Excel للنتائج المفلترة فقط، وبدون تنفيذ معادلات
    x = client.get("/checks/search/xlsx", headers=hdr, params={"account_no": "110205"})
    assert x.status_code == 200 and x.content[:2] == b"PK"
    ws = load_workbook(io.BytesIO(x.content))["الشيكات"]
    rows = list(ws.iter_rows(min_row=2, values_only=True))
    assert len(rows) == 2 and {r[2] for r in rows} == {"7001", "7002"}
    assert any(r[6] == '=HYPERLINK("x")' for r in rows)
    assert ws.auto_filter.ref and ws.cell(2, 7).data_type == "s"
    assert client.get("/checks/search/xlsx", headers=hdr, params={"screen": "Nope"}).status_code == 404
    # غير مصرح
    assert client.get("/checks/search").status_code == 401
    _print_template_checks(client, hdr)


def _print_template_checks(client, hdr):
    base = "/checks/ChecksCairoEgp"  # الدفاتر الثلاثة كلها مستخدمة؛ بنعيد استخدام المربوط في الاختبار اللي فوق من غير ربط جديد
    t = client.get(base + "/print-template", headers=hdr).json()
    assert t["saved"] is False and (t["page_w"], t["page_h"]) == (184.2, 76.2) and len(t["fields"]) == 7
    assert {f["name"] for f in t["fields"]} == {
        "check_date", "payee_note", "beneficiary", "amount_words", "amount_number", "signatory_1", "signatory_2"
    }
    body = {"page_w": 190, "page_h": 80, "offset_x": 1.5, "offset_y": -0.5,
            "fields": [dict(f, x=f["x"] + 2) for f in t["fields"]]}
    r = client.put(base + "/print-template", headers=hdr, json=body)
    assert r.status_code == 200, r.text
    again = client.put(base + "/print-template", headers=hdr, json=body).json()  # حفظ مرتين من غير تكرار صفوف
    got = client.get(base + "/print-template", headers=hdr).json()
    assert got == again and got["saved"] and got["page_w"] == 190 and got["offset_x"] == 1.5 and got["offset_y"] == -0.5
    assert [f["x"] for f in got["fields"]] == [f["x"] + 2 for f in t["fields"]]
    assert client.put(base + "/print-template", headers=hdr, json={**body, "page_w": 10}).status_code == 422
    assert client.put(base + "/print-template", headers=hdr, json={**body, "fields": body["fields"][:3]}).status_code == 422
    bad = [dict(body["fields"][0], align="Middle")] + body["fields"][1:]
    assert client.put(base + "/print-template", headers=hdr, json={**body, "fields": bad}).status_code == 422
