from uuid import uuid4
import pytest
from sqlalchemy import delete, select
from app.database import engine
from app.models import Base


def test_account_filtered_catalog_contract_settlement_and_multi_stock_document(client, hdr):
    suffix = uuid4().hex[:8].upper()
    classifications = client.get('/accounts/classifications', headers=hdr)
    assert classifications.status_code == 200, classifications.text
    classification_id = classifications.json()[0]['classification_id']
    account = client.post('/accounts', headers=hdr, json={
        'account_code': f'IT-{suffix}', 'account_name_ar': f'توريد بازلت 50/100 {suffix}',
        'classification_id': classification_id, 'normal_balance': 'DR',
        'opening_debit': 0, 'opening_credit': 0, 'is_active': True
    })
    assert account.status_code == 201, account.text
    account_id = account.json()['account_id']

    warehouse = client.post('/api/inventory/warehouses', headers=hdr, json={'code':f'WH-{suffix}', 'name':'مخزن اختبار'})
    stock_item = client.post('/api/inventory/items', headers=hdr, json={'code':f'ST-{suffix}', 'name':'بازلـت 50/100', 'unit':'طن'})
    assert warehouse.status_code == 201, warehouse.text
    assert stock_item.status_code == 201, stock_item.text
    catalog = client.post('/api/contracts-erp/catalog-items', headers=hdr, json={
        'code':f'CAT-{suffix}', 'name':'توريد بازلت 50/100', 'unit':'طن',
        'account_id':account_id, 'inventory_item_id':stock_item.json()['item_id']
    })
    assert catalog.status_code == 201, catalog.text
    central_id = catalog.json()['catalog_item_id']
    duplicate_stock_link = client.post('/api/contracts-erp/catalog-items', headers=hdr, json={
        'code':f'CAT-DUP-{suffix}', 'name':'بند آخر لنفس الصنف', 'unit':'طن',
        'account_id':account_id, 'inventory_item_id':stock_item.json()['item_id']
    })
    assert duplicate_stock_link.status_code == 409, duplicate_stock_link.text
    assert 'مرتبط بالفعل' in duplicate_stock_link.json()['detail']
    filtered = client.get(f'/api/contracts-erp/catalog-items?account_id={account_id}', headers=hdr)
    assert filtered.status_code == 200, filtered.text
    assert [x['catalog_item_id'] for x in filtered.json()['items']] == [central_id]

    contract = client.post('/api/contracts', headers=hdr, json={
        'contract_no':f'CT-{suffix}', 'title':'توريد بازلت', 'client_name':'عميل اختبار',
        'original_value':10000, 'status':'Draft'
    })
    assert contract.status_code == 201, contract.text
    cid=contract.json()['contract_id']
    assert contract.json()['status'] == 'PendingEngineering'
    engineering = client.post(f'/api/contracts/{cid}/engineering-approve', headers=hdr)
    assert engineering.status_code == 200 and engineering.json()['status'] == 'PendingFinancial'
    assert client.post(f'/api/contracts/{cid}/approve', headers=hdr).status_code == 200
    line=client.post(f'/api/contracts-erp/{cid}/technical-items', headers=hdr, json={
        'item_no':f'CAT-{suffix}', 'description':'توريد بازلت 50/100', 'unit':'طن',
        'quantity':10, 'unit_price':100, 'catalog_item_id':central_id
    })
    assert line.status_code == 201, line.text
    assert line.json()['item_no'] == '1'  # رقم العقد يولّده الخادم ولا يأخذ رقم البند المركزي المرسل
    assert line.json()['account_id'] == account_id
    duplicate=client.post(f'/api/contracts-erp/{cid}/technical-items', headers=hdr, json={
        'item_no':f'CAT-{suffix}', 'description':'توريد بازلت 50/100', 'unit':'طن',
        'quantity':1, 'unit_price':100, 'catalog_item_id':central_id
    })
    assert duplicate.status_code == 201, duplicate.text
    assert duplicate.json()['item_no'] == '2'  # يظل التسلسل تلقائيًا حتى لو أرسل المتصفح رقمًا مكررًا
    edited=client.put(f"/api/contracts-erp/{cid}/technical-items/{duplicate.json()['item_id']}",headers=hdr,json={
        'item_no':'1','description':'توريد بازلت معدل','unit':'طن','quantity':1,'unit_price':100,'catalog_item_id':central_id
    })
    assert edited.status_code==200,edited.text
    assert edited.json()['item_no']=='2'  # التعديل لا يغيّر رقم البند الثابت
    summary=client.get(f'/api/contracts-erp/{cid}/settlement-summary?settlement_side=Customer',headers=hdr)
    assert summary.json()['items'][0]['account_id'] == account_id
    settlement=client.post(f'/api/contracts-erp/{cid}/settlements',headers=hdr,json={
        'settlement_side':'Customer','settlement_no':f'S-{suffix}','settlement_date':'2030-01-02',
        'counterparty_name':'عميل اختبار','items':[{'contract_item_id':line.json()['item_id'],'quantity':7}], 'vat_rate':0
    })
    assert settlement.status_code == 201, settlement.text
    details=client.get(f"/api/contracts-erp/settlements/{settlement.json()['settlement_id']}/items",headers=hdr)
    assert details.json()['items'][0]['account_id'] == account_id
    assert settlement.json()['work_value'] == '700.00'

    batch=client.post('/api/inventory/movements/batch',headers=hdr,json={
        'movement_no':f'OPEN-{suffix}','warehouse_id':warehouse.json()['warehouse_id'],
        'movement_date':'2030-01-02','movement_type':'IN',
        'lines':[{'item_id':stock_item.json()['item_id'],'quantity':50,'unit_cost':10},
                 {'item_id':stock_item.json()['item_id'],'quantity':25,'unit_cost':11}]
    })
    assert batch.status_code == 201, batch.text
    assert len(batch.json()['items']) == 2
    low=client.post('/api/inventory/movements/batch',headers=hdr,json={
        'movement_no':f'OUT-{suffix}','warehouse_id':warehouse.json()['warehouse_id'],
        'movement_type':'OUT','lines':[{'item_id':stock_item.json()['item_id'],'quantity':80}]
    })
    assert low.status_code == 409, low.text
    balance=client.get('/api/inventory/items',headers=hdr).json()['items']
    row=next(x for x in balance if x['item_id']==stock_item.json()['item_id'])
    assert row['quantity'] == '75.000'
from uuid import uuid4
import pytest
from sqlalchemy import delete, select
from app.database import engine
from app.models import Base
from sqlalchemy import select
from app.database import SessionLocal
from app.models import Company, FiscalYear, ContractAccountingConfig, JournalEntryDetail


@pytest.fixture(autouse=True)
def _remove_rows_created_by_this_test():
    # The test database is shared for the whole pytest session; keep these end-to-end
    # tests isolated so they do not change assumptions in older smoke tests.
    before = {}
    with engine.connect() as conn:
        for table in Base.metadata.sorted_tables:
            pk = next(iter(table.primary_key.columns))
            before[table.name] = set(conn.execute(select(pk)).scalars())
    yield
    with engine.begin() as conn:
        for table in reversed(Base.metadata.sorted_tables):
            pk = next(iter(table.primary_key.columns))
            existing = before[table.name]
            stmt = delete(table).where(pk.not_in(existing)) if existing else delete(table)
            conn.execute(stmt)



def _account(client,hdr,classification_id,code,name,balance):
    response=client.post('/accounts',headers=hdr,json={
        'account_code':code,'account_name_ar':name,'classification_id':classification_id,
        'normal_balance':balance,'opening_debit':0,'opening_credit':0,'is_active':True
    })
    assert response.status_code==201,response.text
    return response.json()['account_id']


def test_mapped_contract_item_posts_to_item_account_without_duplicate(client,hdr):
    token=uuid4().hex[:8].upper()
    classification=client.get('/accounts/classifications',headers=hdr).json()[0]['classification_id']
    item_account=_account(client,hdr,classification,f'REV-{token}','إيراد توريد بازلت','CR')
    control_account=_account(client,hdr,classification,f'AR-{token}','عملاء اختبار','DR')
    fallback_account=_account(client,hdr,classification,f'GL-{token}','حساب أعمال افتراضي','CR')
    with SessionLocal() as db:
        company=Company(name_ar=f'شركة اختبار {token}',name_en='test',is_active=True)
        db.add(company);db.flush();company_id=company.company_id
        fy=FiscalYear(company_id=company_id,start_date=__import__('datetime').date(2030,1,1),end_date=__import__('datetime').date(2030,12,31),is_closed=False)
        db.add(fy);db.flush();fiscal_year_id=fy.fiscal_year_id;db.commit()
    contract=client.post('/api/contracts',headers=hdr,json={'contract_no':f'POST-{token}','title':'عقد اختبار','client_name':'عميل','original_value':1000,'status':'Draft'})
    assert contract.status_code==201,contract.text
    cid=contract.json()['contract_id']
    with SessionLocal() as db:
        db.add(ContractAccountingConfig(contract_id=cid,settlement_side='Customer',company_id=company_id,
            fiscal_year_id=fiscal_year_id,control_account_id=control_account,work_account_id=fallback_account,
            default_vat_rate=0))
        db.commit()
    assert contract.json()['status']=='PendingEngineering'
    engineering=client.post(f'/api/contracts/{cid}/engineering-approve',headers=hdr)
    assert engineering.status_code==200 and engineering.json()['status']=='PendingFinancial'
    assert client.post(f'/api/contracts/{cid}/approve',headers=hdr).status_code==200
    catalog=client.post('/api/contracts-erp/catalog-items',headers=hdr,json={'code':f'CAT-{token}','name':'توريد بازلت','unit':'طن','account_id':item_account})
    assert catalog.status_code==201,catalog.text
    line=client.post(f'/api/contracts-erp/{cid}/technical-items',headers=hdr,json={'item_no':'1','description':'توريد بازلت','unit':'طن','quantity':5,'unit_price':100,'catalog_item_id':catalog.json()['catalog_item_id']})
    assert line.status_code==201,line.text
    settlement=client.post(f'/api/contracts-erp/{cid}/settlements',headers=hdr,json={'settlement_side':'Customer','settlement_no':f'SET-{token}','settlement_date':'2030-05-01','counterparty_name':'عميل','items':[{'contract_item_id':line.json()['item_id'],'quantity':2}],'vat_rate':0})
    assert settlement.status_code==201,settlement.text
    assert settlement.json()['status']=='PendingApproval'
    sid=settlement.json()['settlement_id']
    assert client.post(f'/api/contracts-erp/settlements/{sid}/approve',headers=hdr).status_code==200
    posted=client.post(f'/api/contracts-erp/settlements/{sid}/post',headers=hdr)
    assert posted.status_code==200,posted.text
    assert posted.json()['debit_total']==posted.json()['credit_total']=='200.00'
    with SessionLocal() as db:
        rows=db.scalars(select(JournalEntryDetail).where(JournalEntryDetail.journal_entry_id==posted.json()['journal_entry_id'])).all()
        mapped_credit=[x for x in rows if x.account_id==item_account]
        assert len(mapped_credit)==1 and str(mapped_credit[0].credit_amount)=='200.00'
        assert all(x.account_id!=fallback_account for x in rows)
    duplicate=client.post(f'/api/contracts-erp/settlements/{sid}/post',headers=hdr)
    assert duplicate.status_code==409,duplicate.text
