from uuid import uuid4
from app import database
from app.models import AccountClassification
from sqlalchemy import select


def test_add_supplier_and_contractor_to_unified_party_registry(client, hdr):
    suffix=uuid4().hex[:10]
    for kind,label in (("Supplier","مورد"),("Contractor","مقاول")):
        name=f"{label} اختبار {suffix}"
        response=client.post("/api/counterparties",headers=hdr,json={"legal_name":name,"party_type":kind,"is_active":True})
        assert response.status_code==201,response.text
        assert response.json()["party_type"]==kind
        assert response.json()["legal_name"]==name
    result=client.get("/api/counterparties",headers=hdr,params={"q":suffix})
    assert result.status_code==200,result.text
    assert len(result.json()["items"])==2


def test_counterparty_chart_account_link_is_visible_and_type_checked(client, hdr):
    suffix=uuid4().hex[:10]
    with database.SessionLocal() as db:
        customer_class=db.scalar(select(AccountClassification).where(AccountClassification.name_ar=="عملاء وأوراق قبض"))
        if customer_class is None:
            customer_class=AccountClassification(name_ar="عملاء وأوراق قبض",statement_type="BalanceSheet")
            db.add(customer_class)
        supplier_class=db.scalar(select(AccountClassification).where(AccountClassification.name_ar=="موردون وأوراق دفع"))
        if supplier_class is None:
            supplier_class=AccountClassification(name_ar="موردون وأوراق دفع",statement_type="BalanceSheet")
            db.add(supplier_class)
        db.flush()
        customer_class_id, supplier_class_id=customer_class.classification_id, supplier_class.classification_id
        db.commit()
    customer_account=client.post("/accounts",headers=hdr,json={"account_code":f"CU-{suffix}","account_name_ar":"عميل اختبار","classification_id":customer_class_id,"normal_balance":"DR"})
    supplier_account=client.post("/accounts",headers=hdr,json={"account_code":f"SU-{suffix}","account_name_ar":"مورد اختبار","classification_id":supplier_class_id,"normal_balance":"CR"})
    assert customer_account.status_code==201,customer_account.text
    assert supplier_account.status_code==201,supplier_account.text

    created=client.post("/api/counterparties",headers=hdr,json={"legal_name":f"عميل مربوط {suffix}","party_type":"Customer","linked_account_id":customer_account.json()["account_id"]})
    assert created.status_code==201,created.text
    assert created.json()["linked_account_code"]==f"CU-{suffix}"
    assert created.json()["linked_account_name"]=="عميل اختبار"

    bad=client.post("/api/counterparties",headers=hdr,json={"legal_name":f"عميل بحساب مورد {suffix}","party_type":"Customer","linked_account_id":supplier_account.json()["account_id"]})
    assert bad.status_code==422
    assert "تصنيف العملاء" in bad.json()["detail"]
    choices=client.get("/api/counterparties/chart-accounts",headers=hdr)
    assert choices.status_code==200,choices.text
    assert any(x["account_id"]==customer_account.json()["account_id"] for x in choices.json())
