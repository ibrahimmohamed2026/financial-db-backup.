def _acc(client, hdr, code, name, nb="DR", parent=None, classification_id=1):
    r = client.post("/accounts", headers=hdr, json={"account_code": code, "account_name_ar": name,
                    "classification_id": classification_id, "normal_balance": nb, "parent_account_id": parent})
    assert r.status_code == 201, r.text
    return r.json()["account_id"]


def test_journal_to_trial_balance(client, hdr):
    cash = _acc(client, hdr, "T100", "خزينة اختبار")
    cap = _acc(client, hdr, "T200", "رأس مال اختبار", "CR")
    assert client.post("/journal/fiscal-years", headers=hdr, json={"start_date": "2030-01-01", "end_date": "2030-12-31"}).status_code == 201
    body = {"entry_date": "2030-03-01", "description": "t", "lines": [
        {"account_id": cash, "debit_amount": "100", "description": "إيداع بالخزينة"},
        {"account_id": cap, "credit_amount": "100", "description": "إثبات رأس المال"}]}
    bad = dict(body, lines=[body["lines"][0], {"account_id": cap, "credit_amount": "90", "description": "إثبات رأس المال"}])
    assert client.post("/journal", headers=hdr, json=bad).status_code == 422
    e = client.post("/journal", headers=hdr, json=body)
    assert e.status_code == 201, e.text
    eid = e.json()["journal_entry_id"]
    tb = lambda: client.get("/trial-balance?q=T100", headers=hdr).json()["items"][0]
    assert tb()["td"] == "0.00"                      # مسودة مش بتظهر
    assert client.post(f"/journal/{eid}/post", headers=hdr).status_code == 200
    assert tb()["bd"] == "100.00"
    assert client.put(f"/journal/{eid}", headers=hdr, json=body).status_code == 409
    assert client.post(f"/journal/{eid}/cancel", headers=hdr).status_code == 200
    assert tb()["td"] == "0.00"


def test_treasury_and_checks(client, hdr):
    wrong_class_gl = _acc(client, hdr, "T299", "أصل ثابت اختبار")
    gl = _acc(client, hdr, "T300", "بنك اختبار", classification_id=2)
    assert client.get("/treasury/BankCibEgp/account", headers=hdr).json()["account"] is None
    choices = client.get("/treasury/BankCibEgp/gl-accounts", headers=hdr).json()
    assert gl in {x["account_id"] for x in choices}
    assert wrong_class_gl not in {x["account_id"] for x in choices}
    bad = client.post("/treasury/BankCibEgp/account", headers=hdr, json={"name_ar": "خطأ", "account_type": "Bank",
                    "currency_code": "EGP", "gl_account_id": wrong_class_gl})
    assert bad.status_code == 400
    r = client.post("/treasury/BankCibEgp/account", headers=hdr, json={"name_ar": "CIB", "account_type": "Bank",
                    "currency_code": "EGP", "gl_account_id": gl})
    assert r.status_code == 201, r.text
    new_gl = _acc(client, hdr, "T301", "بنك بديل اختبار", classification_id=2)
    assert client.put("/treasury/BankCibEgp/account", headers=hdr, json={"gl_account_id": new_gl}).status_code == 200
    assert client.get("/treasury/BankCibEgp/account", headers=hdr).json()["account"]["gl_account_id"] == new_gl
    tx = {"transaction_date": "2030-01-05", "inflow": "500"}
    assert client.post("/treasury/BankCibEgp/transactions", headers=hdr, json=tx).status_code == 201
    assert client.post("/treasury/BankCibEgp/transactions", headers=hdr, json={"transaction_date": "2030-01-06", "outflow": "120.5"}).status_code == 201
    t = client.get("/treasury/BankCibEgp/transactions", headers=hdr).json()
    assert t["closing_balance"] == "379.50"
    assert client.get("/treasury/analysis", headers=hdr).json()["totals"][0]["balance"] == "379.50"
    assert client.get("/treasury/Nope/account", headers=hdr).status_code == 404
    # شيكات
    acc = r.json()["treasury_account_id"]
    assert client.post("/checks/ChecksCib/account", headers=hdr, json={"treasury_account_id": acc}).status_code == 200
    b = client.post("/checks/beneficiaries", headers=hdr, json={"name_ar": "مورد"}).json()["beneficiary_id"]
    c = client.post("/checks/ChecksCib/items", headers=hdr, json={"check_book_no": "A", "sequence_no": 1,
                    "beneficiary_id": b, "amount": "50"})
    assert c.status_code == 201, c.text
    cid = c.json()["check_id"]
    assert client.post(f"/checks/ChecksCib/items/{cid}/status", headers=hdr, json={"status": "تم الصرف"}).status_code == 409
    assert client.post(f"/checks/ChecksCib/items/{cid}/status", headers=hdr, json={"status": "تم التسليم"}).status_code == 200
    # تسوية
    rec = client.post("/reconciliations", headers=hdr, json={"treasury_account_id": acc, "reconciliation_date": "2030-02-01", "statement_balance": "400"})
    assert rec.status_code == 201 and rec.json()["difference"] == "20.50"


def test_cash_usd_account_is_server_saved_and_requires_active_leaf_gl(client, hdr):
    parent = _acc(client, hdr, "TCASH-P", "حساب رئيسي نقدية اختبار", classification_id=2)
    child = _acc(client, hdr, "TCASH-C", "حساب فرعي نقدية اختبار", parent=parent, classification_id=2)
    inactive = client.post("/accounts", headers=hdr, json={"account_code": "TCASH-I", "account_name_ar": "حساب نقدية موقوف",
                           "classification_id": 2, "normal_balance": "DR", "is_active": False})
    assert inactive.status_code == 201, inactive.text

    choices = client.get("/treasury/CashUsd/gl-accounts", headers=hdr).json()
    offered = {x["account_id"] for x in choices}
    assert parent not in offered and inactive.json()["account_id"] not in offered

    for invalid_id in (parent, inactive.json()["account_id"]):
        rejected = client.post("/treasury/CashUsd/account", headers=hdr, json={"name_ar": "خزينة دولار اختبار",
                               "account_type": "Cash", "currency_code": "USD", "gl_account_id": invalid_id})
        assert rejected.status_code == 400

    saved = client.post("/treasury/CashUsd/account", headers=hdr, json={"name_ar": "خزينة دولار اختبار",
                          "account_type": "Cash", "currency_code": "USD", "gl_account_id": child})
    assert saved.status_code == 201, saved.text
    account = client.get("/treasury/CashUsd/account", headers=hdr).json()["account"]
    assert account["treasury_account_id"] == saved.json()["treasury_account_id"]
    assert account["gl_account_id"] == child


def test_reports(client, hdr):
    assert client.get("/reports/balance-sheet", headers=hdr).status_code == 200
    assert client.get("/reports/income-statement", headers=hdr).status_code == 200
